seed=${RANDOM}
CUDA_VISIBLE_DEVICES=1 nohup python train_rl.py>/public/home/huarong/yixiulong/RM/Train/RL_Tag/results/MIMIC-CXR/B4-M-R-515-Focal3/B4-M-R-515-Focal.out \
--image_dir data/mimic_cxr/images/ \
--ann_path data/mimic_cxr/annotation.json \
--dataset_name mimic_cxr \
--max_seq_length 100 \
--threshold 10 \
--batch_size 6 \
--epochs 50 \
--save_dir /public/home/huarong/yixiulong/RM/Train/RL_Tag/results/MIMIC-CXR/B4-M-R-515-Focal3 \
--step_size 1 \
--d_vf 2048 \
--gamma 0.8 \
--early_stop 5 \
--num_layers 3 \
--seed ${seed} \
--resume /public/home/huarong/yixiulong/RM/Train/RL_Tag/results/MIMIC-CXR/XE/model_best.pth