seed=${RANDOM}
noamopt_warmup=1000
CUDA_VISIBLE_DEVICES=0 nohup python train_rl.py>/public/home/huarong/yixiulong/RM/Train/RL_Tag/results/IU-X-Ray/B4-M-R-515-Focal/B4-M-R-515-Focal.out \
    --image_dir data/iu_xray/images/ \
    --ann_path data/iu_xray/annotation.json \
    --dataset_name iu_xray \
    --max_seq_length 60 \
    --threshold 3 \
    --batch_size 10 \
    --epochs 120 \
    --save_dir /public/home/huarong/yixiulong/RM/Train/RL_Tag/results/IU-X-Ray/B4-M-R-515-Focal \
    --step_size 1 \
    --gamma 0.8 \
    --seed ${seed} \
    --beam_size 3 \
    --log_period 100 \
    --early_stop 100 \
    --d_vf 2048 \
    --n_gpu 1 \
    --resume /public/home/huarong/yixiulong/RM/Train/RL_Tag/results/IU-X-Ray/XE/model_best.pth
